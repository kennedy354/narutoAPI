import { useEffect, useState } from "react";
import axios from "axios";

function Digimon(){

    const [digimon, setDigimon] = useState([])

    useEffect(()=> {
        getDigimon()
    }, [])

    const getDigimon = () =>{
        axios
        .get("https://naruto-api.fly.dev/api/v1/characters")
        .then((res) => setDigimon(res.data))
        .catch((err) => console.log(err))
    }

    return(
        <>
        <h1>Digimon</h1>
        


        <table>
            <thead>
            <tr>
                <th>Nome</th>
                <th>Foto</th>
                <th>Level</th>
            </tr>
            </thead>

            <tbody>
            {digimon.map((digimons, key) => (
                    <tr key={key}>
                        <td>{digimons.name}</td>
                        <td><img src={digimons.images[1]}></img></td>
                        <td>{digimons.level}</td>
                    </tr>
            ))}
            </tbody>
        </table>
        </>
    )
}

export default Digimon