import { useState } from 'react'
import { Routes, Route } from "react-router-dom"
import HomePage from "./Pages/HomePage"
import Naruto from './components/Naruto'

function App() {
  const [count, setCount] = useState(0)

  document.body.classList.add('paginaInteira');
  
  return (
    <>
    <div className="App">
      <h1>API Trabalho</h1>
    </div>

    <Routes>
      <Route path="/" element={<HomePage></HomePage>}>
        <Route index element={<span>Bem vindo</span>}></Route>
        <Route path="naruto" element={<Naruto/>} />
      </Route>
    </Routes>

    </>
  )
}

export default App
