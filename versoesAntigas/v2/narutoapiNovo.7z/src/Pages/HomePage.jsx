import { Link,Outlet } from "react-router-dom"

function HomePage(){
    return(
        <>
            <p><Link to="/">Inicio</Link></p>
            <p><Link to="/naruto">Naruto</Link></p>
            <div>
                <Outlet />
            </div>
        </>
    )
}
export default HomePage