import { useEffect, useState } from "react";
import '/src/style/estilo.css';
import axios from "axios";

function Naruto(){

    const [naruto, setNaruto] = useState([])

    useEffect(()=> {
        getNaruto()
    }, [])

    const getNaruto = () =>{
        axios
        .get("https://naruto-api.fly.dev/api/v1/characters")
        .then((res) => setNaruto(res.data))
        .catch((err) => console.log(err))
    }

    return(
        <>
        <h1>Personagens</h1>
        
        <div className="todos">

            {naruto.map((personagens, key) => (
                    <div className="personagem" key={key}>
                        <div className="nomePersonagem"><div className="nomeInterior">{personagens.name.replace('_', ' ')}</div></div>
                        <div className="imagemPersonagem"><img className="imagemInterior" src={personagens.images[0] || personagens.images[1]}></img></div>
                        <div className="vilaPersonagem"><div className="vilaInterior">{personagens.info.Afiliação.replace(' (Apenas Anime)', '')}</div></div>
                    </div>
            ))}
            
        </div>
        </>
    )
}

export default Naruto